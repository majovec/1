# Model a vyhodnocování

Backtest používá chronologické expanding-window testování: každý testovaný zápas se předpovídá z předchozí historie, nikoli z dat po zápase. Metriky: accuracy 1/X/2, log loss a Brier score. Menší log loss/Brier je lepší; accuracy sama nestačí.

Aktuální baseline je Poissonův model z výsledků gólů. Neobsahuje zatím xG, sestavy, zranění, odpočinek, kurzy ani sofistikovanou kalibraci. Nejde o prokázaně ziskový systém. Před rozhodováním je třeba více sezón a dostatečně velký testovací vzorek.

GitHub Actions je dočasný runner. Pro dlouhodobé sledování napříč běhy je potřeba předávat artefakt ručně, nebo v další iteraci přidat trvalé úložiště.
