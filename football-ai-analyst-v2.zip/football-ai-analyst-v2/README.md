# Football AI Analyst v2

MVP pro historické ověřování fotbalových předpovědí a testování aktuálních zápasů bez vlastního serveru.

## Co umí
- Načte data z football-data.org (pro živá data je potřeba API klíč).
- Historické zápasy testuje chronologicky: každý testovaný zápas se předpovídá pouze z dřívějších zápasů.
- Vypočítá pravděpodobnosti 1/X/2, očekávané góly, Over 2,5 a BTTS.
- Vypočítá accuracy, log loss a Brier score.
- Jedním tlačítkem v GitHub Actions vytvoří predikce nadcházejících zápasů.
- Obsahuje `build.yml`, který nainstaluje projekt, spustí testy a zabalí celý zdrojový projekt do ZIP artefaktu.

## Instalace
1. Rozbal ZIP.
2. Vytvoř na GitHubu nový repozitář, doporučeně Private.
3. Nahraj **obsah** rozbalené složky do kořene repozitáře. `.github` musí být v kořeni.
4. GitHub → Settings → Secrets and variables → Actions → New repository secret:
   - Name: `FOOTBALL_DATA_API_KEY`
   - Value: API klíč z football-data.org
5. Volitelně přidej Variables `FOOTBALL_DATA_COMPETITION` (např. `PL`) a `FOOTBALL_DATA_SEASON` (např. `2025`).
6. Otevři Actions a spusť `Build and Test`, pak `Train and Backtest`, potom `Predict Upcoming Matches`.

## Workflow tlačítka
- `Build and Test` (`build.yml`): testy a ZIP zdrojového projektu jako artefakt.
- `Train and Backtest` (`train.yml`): chronologický historický test, report a parametry modelu.
- `Predict Upcoming Matches` (`predict.yml`): předpovědi pro dostupné budoucí zápasy.
- `Settle Predictions` (`settle.yml`): vyhodnocení již uložených predikcí po zápasech. Pro první verzi musí být `predictions.json` z předchozího artefaktu ručně přidán do repozitáře pod `data/predictions.json`.

## Důležité limity
Dva dny nepřetržitého běhu samy o sobě nezaručí kvalitu. Proto je důležitější chronologický test na historických datech a následné pozorování skutečných předpovědí. Výsledky závisejí na pokrytí datového poskytovatele a dostupném API plánu. Model zatím není ověřeně ziskový ani profesionální. GitHub Actions runner je dočasný; bez trvalého úložiště se historie mezi běhy automaticky nepřenáší.

## Lokální spuštění
```bash
pip install -r requirements.txt
pytest -q
python -m app.jobs.backtest
python -m app.jobs.predict_upcoming
streamlit run dashboard.py
```
