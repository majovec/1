import pandas as pd
from config import DATA, MATCHES, SAMPLE, API_KEY, COMPETITION, SEASON
from app.data.provider import fetch_matches
from app.data.validation import validate

def get_data():
    DATA.mkdir(parents=True, exist_ok=True)
    if API_KEY:
        df = fetch_matches(API_KEY, COMPETITION, SEASON or None)
    else:
        path = MATCHES if MATCHES.exists() else SAMPLE
        if not path.exists(): raise ValueError("Chybí lokální data a API klíč.")
        df = pd.read_csv(path)
    df = validate(df)
    df.to_csv(MATCHES, index=False)
    return df
