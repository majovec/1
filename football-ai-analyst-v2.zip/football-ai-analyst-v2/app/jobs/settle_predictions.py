import json
import pandas as pd
from config import DATA, PREDICTIONS, SETTLED
from app.jobs.common import get_data
from app.models.poisson import outcome, log_loss, brier

def main():
    if not PREDICTIONS.exists(): raise SystemExit("Nahraj předchozí data/predictions.json a spusť znovu.")
    pred = json.loads(PREDICTIONS.read_text(encoding="utf-8"))
    df = get_data()
    finished = df[df.home_goals.notna() & df.away_goals.notna()]
    settled, pending = [], []
    for p in pred.get("predictions",[]):
        date = pd.to_datetime(p["date"],utc=True)
        matches = finished[(finished.home_team==p["home_team"]) & (finished.away_team==p["away_team"]) & (finished.date==date)]
        if matches.empty:
            pending.append(p); continue
        r = matches.iloc[-1]; actual=outcome(int(r.home_goals),int(r.away_goals))
        item=dict(p,actual=actual,actual_score=f"{int(r.home_goals)}:{int(r.away_goals)}",log_loss=log_loss(p,actual),brier=brier(p,actual))
        settled.append(item)
    metrics = {"accuracy_1x2":sum(max([("H",p["p_home"]),("D",p["p_draw"]),("A",p["p_away"])],key=lambda x:x[1])[0]==p["actual"] for p in settled)/len(settled) if settled else None,
               "mean_log_loss":sum(p["log_loss"] for p in settled)/len(settled) if settled else None,
               "mean_brier_1x2":sum(p["brier"] for p in settled)/len(settled) if settled else None}
    DATA.mkdir(exist_ok=True)
    SETTLED.write_text(json.dumps({"settled_count":len(settled),"pending_count":len(pending),"metrics":metrics,"settled":settled,"pending":pending},ensure_ascii=False,indent=2),encoding="utf-8")
if __name__ == "__main__": main()
