import json
from config import DATA, PREDICTIONS
from app.jobs.common import get_data
from app.models.poisson import fit_model, predict

def main():
    df = get_data()
    finished = df[df.home_goals.notna() & df.away_goals.notna()]
    upcoming = df[df.home_goals.isna() | df.away_goals.isna()]
    if finished.empty: raise SystemExit("Není dost dohraných zápasů pro model.")
    if upcoming.empty: raise SystemExit("API nevrátilo žádné budoucí zápasy. Zkontroluj soutěž, sezónu a dostupnost dat.")
    model = fit_model(finished)
    out = []
    for _, r in upcoming.sort_values("date").iterrows():
        p = predict(model,str(r.home_team),str(r.away_team))
        p.update({"match_id":str(r.get("match_id","")),"date":r.date.isoformat(),"status":r.get("status","SCHEDULED"),
                  "competition":r.get("competition",""),"prediction_id":f"{r.date.isoformat()}|{r.home_team}|{r.away_team}"})
        out.append(p)
    DATA.mkdir(exist_ok=True)
    PREDICTIONS.write_text(json.dumps({"generated_at":pd.Timestamp.now(tz="UTC").isoformat(),"model":model["version"],
      "training_matches":len(finished),"upcoming_matches":len(out),"predictions":out,
      "note":"Pravděpodobnostní odhady nejsou jisté tipy."},ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Vytvořeno {len(out)} predikcí.")
import pandas as pd
if __name__ == "__main__": main()
