import json
import pandas as pd
from config import DATA, REPORT, MODEL
from app.jobs.common import get_data
from app.models.poisson import fit_model, predict, outcome, log_loss, brier

def run_backtest(df, min_train=12):
    d = df[df.home_goals.notna() & df.away_goals.notna()].sort_values("date").reset_index(drop=True)
    rows = []
    for i in range(min_train, len(d)):
        hist, r = d.iloc[:i], d.iloc[i]
        p = predict(fit_model(hist), str(r.home_team), str(r.away_team))
        actual = outcome(int(r.home_goals), int(r.away_goals))
        p.update({"date":r.date.isoformat(),"actual":actual,"score":f"{int(r.home_goals)}:{int(r.away_goals)}",
                  "log_loss":log_loss(p,actual),"brier":brier(p,actual),
                  "correct":max([("H",p["p_home"]),("D",p["p_draw"]),("A",p["p_away"])],key=lambda x:x[1])[0]==actual})
        rows.append(p)
    metrics = None
    warning = None
    if rows:
        test = pd.DataFrame(rows)
        metrics = {"accuracy_1x2":float(test.correct.mean()),"mean_log_loss":float(test.log_loss.mean()),"mean_brier_1x2":float(test.brier.mean())}
        if len(rows) < 50: warning = "Méně než 50 testovaných zápasů: metriky jsou velmi nejisté."
    else:
        warning = f"Nedostatek historie; je potřeba alespoň {min_train+1} dohraných zápasů."
    return {"model":"Poisson baseline v2","matches_tested":len(rows),"metrics":metrics,"warning":warning,
            "method":"Chronologický expanding-window test; testovaný zápas se nikdy nepoužije k tréninku své vlastní předpovědi.","results":rows}

def main():
    df = get_data()
    finished = df[df.home_goals.notna() & df.away_goals.notna()]
    report = run_backtest(df)
    DATA.mkdir(exist_ok=True)
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    if len(finished): MODEL.write_text(json.dumps(fit_model(finished),ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Backtest hotov. Testováno zápasů: {report['matches_tested']}")
if __name__ == "__main__": main()
