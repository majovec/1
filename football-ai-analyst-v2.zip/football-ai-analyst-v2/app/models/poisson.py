import numpy as np
import pandas as pd
from scipy.stats import poisson

def _mean(x, fallback):
    s = pd.to_numeric(pd.Series(x), errors="coerce").dropna()
    return float(s.mean()) if len(s) else float(fallback)

def fit_model(history):
    hmean = max(_mean(history["home_goals"], 1.45), .15)
    amean = max(_mean(history["away_goals"], 1.15), .15)
    league = (hmean + amean) / 2
    teams = sorted(set(history.home_team.astype(str)) | set(history.away_team.astype(str)))
    params = {}
    for t in teams:
        scored = list(history.loc[history.home_team == t, "home_goals"].dropna()) + list(history.loc[history.away_team == t, "away_goals"].dropna())
        conceded = list(history.loc[history.home_team == t, "away_goals"].dropna()) + list(history.loc[history.away_team == t, "home_goals"].dropna())
        n = len(scored); shrink = n / (n + 8)
        attack = _mean(scored, league) / max(league, .15)
        defence = _mean(conceded, league) / max(league, .15)
        params[t] = {"attack": float(shrink*attack + 1-shrink), "defence": float(shrink*defence + 1-shrink), "matches": n}
    return {"league_home": hmean, "league_away": amean, "teams": params, "version": "poisson-baseline-v2"}

def predict(model, home, away, max_goals=10):
    teams = model["teams"]
    h = teams.get(home, {"attack":1., "defence":1.})
    a = teams.get(away, {"attack":1., "defence":1.})
    lh = float(np.clip(model["league_home"]*h["attack"]/max(a["defence"],.2), .15, 4.5))
    la = float(np.clip(model["league_away"]*a["attack"]/max(h["defence"],.2), .15, 4.5))
    g = np.arange(max_goals+1)
    mat = np.outer(poisson.pmf(g,lh), poisson.pmf(g,la)); mat /= mat.sum()
    over = float(sum(mat[i,j] for i in range(max_goals+1) for j in range(max_goals+1) if i+j>=3))
    top = sorted([(float(mat[i,j]),i,j) for i in range(max_goals+1) for j in range(max_goals+1)], reverse=True)[:5]
    return {"home_team":home,"away_team":away,"expected_home_goals":round(lh,3),"expected_away_goals":round(la,3),
            "p_home":float(np.tril(mat,-1).sum()),"p_draw":float(np.trace(mat)),"p_away":float(np.triu(mat,1).sum()),
            "p_over_2_5":over,"p_under_2_5":1-over,"p_btts":float(mat[1:,1:].sum()),
            "top_scores":[{"score":f"{i}:{j}","probability":p} for p,i,j in top]}

def outcome(h,a):
    return "H" if h>a else "D" if h==a else "A"

def log_loss(pred, actual):
    p = {"H":pred["p_home"],"D":pred["p_draw"],"A":pred["p_away"]}[actual]
    return float(-np.log(max(min(p,1-1e-12),1e-12)))

def brier(pred, actual):
    probs = np.array([pred["p_home"],pred["p_draw"],pred["p_away"]])
    target = np.array([actual=="H",actual=="D",actual=="A"],dtype=float)
    return float(np.sum((probs-target)**2))
