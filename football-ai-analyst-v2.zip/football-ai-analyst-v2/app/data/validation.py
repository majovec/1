import pandas as pd
REQUIRED = {"date","home_team","away_team","home_goals","away_goals"}

def validate(df):
    missing = REQUIRED - set(df.columns)
    if missing: raise ValueError("Chybí sloupce: " + ", ".join(sorted(missing)))
    d = df.copy()
    d["date"] = pd.to_datetime(d["date"], utc=True, errors="coerce")
    if d["date"].isna().any(): raise ValueError("Neplatné datum zápasu.")
    for c in ("home_team","away_team"):
        d[c] = d[c].fillna("").astype(str).str.strip()
        if (d[c] == "").any(): raise ValueError(f"Prázdný tým ve sloupci {c}.")
    for c in ("home_goals","away_goals"):
        d[c] = pd.to_numeric(d[c], errors="coerce")
        bad = d[c].notna() & (d[c] < 0)
        if bad.any(): raise ValueError("Počet gólů nesmí být záporný.")
    return d.drop_duplicates(["date","home_team","away_team"], keep="last").sort_values("date").reset_index(drop=True)
