import requests
import pandas as pd
BASE = "https://api.football-data.org/v4"

def fetch_matches(api_key, competition="PL", season=None):
    if not api_key:
        raise ValueError("Chybí FOOTBALL_DATA_API_KEY.")
    params = {"season": season} if season else {}
    r = requests.get(f"{BASE}/competitions/{competition}/matches",
                     headers={"X-Auth-Token": api_key}, params=params, timeout=40)
    r.raise_for_status()
    rows = []
    for m in r.json().get("matches", []):
        score = (m.get("score") or {}).get("fullTime") or {}
        rows.append({"match_id": str(m.get("id", "")), "date": m.get("utcDate"),
                     "status": m.get("status", ""), "home_team": (m.get("homeTeam") or {}).get("name", ""),
                     "away_team": (m.get("awayTeam") or {}).get("name", ""),
                     "home_goals": score.get("home"), "away_goals": score.get("away"),
                     "competition": competition, "source": "football-data.org"})
    return pd.DataFrame(rows)
