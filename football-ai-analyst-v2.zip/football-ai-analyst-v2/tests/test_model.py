import pandas as pd
import pytest
from app.data.validation import validate
from app.models.poisson import fit_model,predict,outcome,log_loss,brier

def sample():
    return pd.DataFrame([
      {"date":"2025-01-01","home_team":"A","away_team":"B","home_goals":2,"away_goals":0},
      {"date":"2025-01-02","home_team":"B","away_team":"C","home_goals":1,"away_goals":1},
      {"date":"2025-01-03","home_team":"C","away_team":"A","home_goals":0,"away_goals":2},
      {"date":"2025-01-04","home_team":"A","away_team":"C","home_goals":3,"away_goals":1},
      {"date":"2025-01-05","home_team":"B","away_team":"A","home_goals":0,"away_goals":1},
      {"date":"2025-01-06","home_team":"C","away_team":"B","home_goals":2,"away_goals":2}])
def test_validation():
    with pytest.raises(ValueError): validate(pd.DataFrame([{"home_team":"A"}]))
def test_dedup():
    assert len(validate(pd.concat([sample(),sample().iloc[[0]]])))==6
def test_probabilities():
    p=predict(fit_model(validate(sample())),"A","B")
    assert abs(p["p_home"]+p["p_draw"]+p["p_away"]-1)<1e-8
    assert 0<=p["p_over_2_5"]<=1 and 0<=p["p_btts"]<=1
def test_metrics():
    p=predict(fit_model(validate(sample())),"A","B")
    assert log_loss(p,outcome(2,0))>=0 and brier(p,outcome(2,0))>=0
