from pathlib import Path
import json
import pandas as pd
import streamlit as st
from config import REPORT, PREDICTIONS
st.set_page_config(page_title="Football AI Analyst",page_icon="⚽",layout="wide")
st.title("⚽ Football AI Analyst")
st.caption("Historické ověřování a pravděpodobnosti aktuálních zápasů")
a,b=st.tabs(["Historický test","Aktuální předpovědi"])
with a:
    if REPORT.exists():
        r=json.loads(REPORT.read_text(encoding="utf-8"))
        st.metric("Testováno zápasů",r.get("matches_tested",0))
        if r.get("metrics"):
            x,y,z=st.columns(3); m=r["metrics"]
            x.metric("Přesnost 1/X/2",f"{m['accuracy_1x2']*100:.1f}%")
            y.metric("Log loss ↓",f"{m['mean_log_loss']:.3f}")
            z.metric("Brier score ↓",f"{m['mean_brier_1x2']:.3f}")
        if r.get("warning"): st.warning(r["warning"])
        st.caption(r.get("method",""))
    else: st.info("Spusť Actions → Train and Backtest.")
with b:
    if PREDICTIONS.exists():
        r=json.loads(PREDICTIONS.read_text(encoding="utf-8")); rows=r.get("predictions",[])
        st.write(f"Vytvořeno: {r.get('generated_at','—')} · Zápasů: {len(rows)}")
        if rows:
            d=pd.DataFrame(rows); d["Zápas"]=d.home_team+" – "+d.away_team
            for c,l in [("p_home","1"),("p_draw","X"),("p_away","2"),("p_over_2_5","Over 2,5"),("p_btts","BTTS")]:
                d[l]=d[c].map(lambda v:f"{v*100:.1f}%")
            st.dataframe(d[["date","Zápas","expected_home_goals","expected_away_goals","1","X","2","Over 2,5","BTTS"]],use_container_width=True,hide_index=True)
    else: st.info("Spusť Actions → Predict Upcoming Matches.")
st.divider()
st.caption("MVP: výsledky jsou odhady, ne garance. Malý historický vzorek nestačí k prokázání kvality.")
