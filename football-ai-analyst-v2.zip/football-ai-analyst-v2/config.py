import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
MATCHES = DATA / "matches.csv"
SAMPLE = DATA / "sample_matches.csv"
REPORT = DATA / "backtest_report.json"
MODEL = DATA / "model.json"
PREDICTIONS = DATA / "predictions.json"
SETTLED = DATA / "settled_report.json"
API_KEY = os.getenv("FOOTBALL_DATA_API_KEY", "").strip()
COMPETITION = os.getenv("FOOTBALL_DATA_COMPETITION", "PL").strip() or "PL"
SEASON = os.getenv("FOOTBALL_DATA_SEASON", "").strip()
